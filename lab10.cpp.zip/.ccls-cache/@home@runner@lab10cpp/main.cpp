#include <iostream>
using namespace std;
int main() {
int char_count=0;
  int lower=0;
  int upper=0;
  int digit=0;
  int space=0;
  string s;
  char c;
  cin.get(c);
  while (c != '#') {
    if (islower(c)) {
      lower++;
  }
    else if (isupper(c)) {
      upper++;
    }
    else if (isdigit(c)) {
      digit++;
    }
    else if (isspace(c)) {
      space++;
    }
    cin.get(c);
  }
  char_count = lower + upper + digit + space;
  cout << char_count << endl;
  cout << lower << endl;
  cout << upper << endl;
  cout << digit << endl;
  cout << space << endl;
  return 0;
}