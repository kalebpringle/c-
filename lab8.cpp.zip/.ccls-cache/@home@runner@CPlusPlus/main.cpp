#include <iostream>
using namespace std;
int main() {
 int n ;
  cout<< "How many times should I print?" << endl;
  cin>>n;
  int i=1;
  while(i<=n){
  cout<<i<<" I love computer science!!"<<endl;
    i=i+1;
    
  }
  cout << "Printed this message " << n << " times." << endl;
  return 0;
}