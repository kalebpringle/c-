#include <iostream>
using namespace std;
int main() {
  double g = 9.8;
  cout << "Please input the time of fall in seconds: ";
  double t;
  cin >> t;
  cout << "Please input the height of the bridge in meters: ";
  double h;
  cin >> h;
  double d = 0.0;
  bool valid = true;

  cout << "Time Falling (seconds)  Distance Fallen (meters)\n";
  cout << "*******************************************\n";

  for (int i = 0; i <= t; ++i) {
      d = 0.5 * g * i * i;
      cout << i << " " << d << endl;
      if (d > h) {
          valid = false;
          break;
      }
  }

  if (!valid) {
      cout << "Warning-Bad Data: The distance fallen exceeds the height of the bridge" << endl;
  }
  
  
return 0;
}